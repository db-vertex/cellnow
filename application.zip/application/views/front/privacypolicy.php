<div class="container bg-3 divpad">   
<center><img  src="<?php echo base_url();?>assets/images/privacy.png">  </center> 
  <h3 class="text-center">Privacy Policy</h3><br>
  <div class="row" style="margin-bottom: 30px;">
    


  
  <?php

  //print_r($privacy);

echo $privacy['0']['privacy_policy'];

   ?>

   </div>

</div>